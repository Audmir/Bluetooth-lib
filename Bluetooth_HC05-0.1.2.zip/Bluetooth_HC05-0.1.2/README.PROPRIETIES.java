This library was created by: AUDREY MIRINDI
by the AMTECH company setted in BUKAVU/RDCONGO
MAIL: audreymirindi001@gmail.com
twitter: @audrey_mirindi
facebook: audrey mirindi technology king

Sentence: This library is consisting to help you dealing with HC05 Bluetooth Module
