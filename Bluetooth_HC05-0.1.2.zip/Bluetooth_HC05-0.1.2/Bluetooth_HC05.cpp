/*
  This library will help you to program the HC05
  bluetooth module.
  it better to use it because of the HC05 configuration.
*/

#include"Bluetooth_HC05.h"

HC05::HC05(void) {
  this->value;
}

void HC05::begin(uint16_t baud) {
  if (baud > 57600) {
    return;
  } else {
    Serial.begin(baud);
  }
}

int HC05::available(void) {
  return Serial.available();
}

char HC05::read(void) {
  char Signal = Serial.read();
  return Signal;
}

void HC05::peek(void) {
  return Serial.peek();
}

void HC05::flush(void) {
  return Serial.flush();
}

byte HC05::write(byte message) {
  Serial.write(message);
}

int HC05::btMode(int bt) {
  if (bt == 1) {
    ;
  }
}

