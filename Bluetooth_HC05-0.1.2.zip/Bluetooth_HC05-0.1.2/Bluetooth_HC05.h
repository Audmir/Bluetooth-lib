


#ifndef Bluetooth_HC05_h
#define Bluetooth_HC05_h

#if ARDUINO < 100
#include<WProgram.h>
#else
#include<arduino.h>

#endif

#define HC05BT 1
#define HC06T 1
#define BT05 1
#define NONE 0

class HC05 {
  public:
    HC05(void);
    void begin(uint16_t baud = NULL);
    virtual int available(void);
    char read(void);
    void peek(void);
    void flush(void);
    byte write(byte message);
    virtual int btMode(int bt);
  private:
    char value;
    
};


#endif
